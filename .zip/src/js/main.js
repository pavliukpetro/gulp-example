function log(message) {
    console.log(message);
}

log('Hello Gulp!');
